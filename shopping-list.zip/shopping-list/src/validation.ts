export function validateItem(name: string, quantityText: string): string | null {
  const trimmedName = name.trim();

  if (trimmedName.length < 2 || trimmedName.length > 30) {
    return "Nazwa musi mieć od 2 do 30 znaków.";
  }

  const qty = Number(quantityText);
  if (isNaN(qty) || !Number.isInteger(qty) || qty < 1 || qty > 99) {
    return "Ilość musi być liczbą całkowitą od 1 do 99.";
  }

  return null;
}
